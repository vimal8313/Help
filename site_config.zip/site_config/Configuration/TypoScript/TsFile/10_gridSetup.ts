# ------------------------------------------------
# Assigning grids, config grid header usage
#

# Don't show header
tt_content.gridelements_pi1.10 >

# Change if gridelements have diffferent IDs.
/*
tt_content.gridelements_pi1.20.10.setup {
    10 < lib.bootstrap_grids.GridForKontact
    11 < lib.bootstrap_grids.3cols
    12 < lib.bootstrap_grids.4cols
}
*/
tt_content.gridelements_pi1.20.10 {
    setup {
        # 2 column grid
        1{
            wrap = <div class=""><div class="row">|</div></div>
            columns {
                1 {
                    renderObj =< tt_content
                    wrap =  <div class=""><div class="">|</div></div>
                }
                2 {
                    renderObj =< tt_content
                    wrap =  <div class=""><div class="">|</div></div>
                }
            }
        }
        # 1 column grid
        2{
            wrap = <div class="">|</div>
            columns {
                1 {
                    renderObj =< tt_content
                }
            }
        }
    }
}
