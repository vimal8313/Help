
page.shortcutIcon = EXT:site_config/Resources/Public/images/iconfv.png