page.includeCSS{
	bootstrap = EXT:site_config/Resources/Public/css/bootstrap.css
	css3 = EXT:site_config/Resources/Public/css/css3.css
	docs = EXT:site_config/Resources/Public/css/docs.css
	slick = EXT:site_config/Resources/Public/css/slick.css
	slicktheme = EXT:site_config/Resources/Public/css/slick-theme.css
	fontawesome = EXT:site_config/Resources/Public/css/font-awesome.css
	#font = https://fonts.googleapis.com/css?family=Caveat+Brush
	#font.external = 1
}
page.headerData{
	10	 = TEXT
	10.value(
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	    <!--[if lt IE 9]>
	     	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	    <![endif]-->	
	)
}