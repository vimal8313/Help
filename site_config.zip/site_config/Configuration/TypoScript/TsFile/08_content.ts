# Setup each colPos blocks.
lib.contentmain < styles.content.get
lib.contentmain.select.where = colPos = 0
lib.content1 < styles.content.get
lib.content1.select.where = colPos = 1
lib.content2 < styles.content.get
lib.content2.select.where = colPos = 2
lib.content3 < styles.content.get
lib.content3.select.where = colPos = 3
lib.content401 < styles.content.get
lib.content401.select.where = colPos = 401
lib.content402 < styles.content.get
lib.content402.select.where = colPos = 402
lib.content403 < styles.content.get
lib.content403.select.where = colPos = 403
lib.content404 < styles.content.get
lib.content404.select.where = colPos = 404
lib.content405 < styles.content.get
lib.content405.select.where = colPos = 405


# Background Image
lib.backgroundImg = COA
lib.backgroundImg {
	10 = FILES
	10 {
		references {
			table = pages
			data = levelmedia:-1,slide
			listNum = 0
		}
		renderObj = COA
		renderObj {
			10 = IMG_RESOURCE
			10 {
				file.import.data = file:current:originalUid // file:current:uid
				altText.data = file:current:title
			}
			
		}
	}
}


lib.breadcrumb=COA
lib.breadcrumb {
    10 = HMENU
    10 {
        special = rootline
        special.range = 1
        # "not in menu pages" should show up in the breadcrumbs menu
        includeNotInMenu = 1
        1 = TMENU
        1 {
            noBlur = 1
            # Current item should be unlinked
            target = _self
            wrap = <ul> | </ul>
            NO {
                stdWrap.field = title
                ATagTitle.field = nav_title // title
                linkWrap = <li>|</li><li>&gt;</li>|*|<li>|</li><li>&gt;</li>|*|<li>|</li>
            }
            # Current menu item is unlinked
            CUR = 1
            # < .NO
            CUR.linkWrap = <li>|</li><li>&gt;</li>|*|<li>|</li><li>&gt;</li>|*|<li class="active">|</li>
            CUR.doNotLinkIt = 1
 
        }
    }
}