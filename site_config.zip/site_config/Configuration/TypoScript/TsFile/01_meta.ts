page.meta.charset = utf-8
page.meta.X-UA-Compatible = IE=edge
page.meta.X-UA-Compatible.attribute = http-equiv
page.meta.viewport = width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0
page.meta.format-detection=telephone=no
page.meta.description = {page:description}
page.meta.description.insertData = 1
page.meta.keywords = {page:keywords}
page.meta.keywords.insertData = 1
