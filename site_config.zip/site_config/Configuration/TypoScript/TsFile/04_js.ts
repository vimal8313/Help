# Footer JS
page.includeJSFooter{
	#jquery = EXT:site_config/Resources/Public/js/jquery-1.12.4.min.js
	bootstrap = EXT:site_config/Resources/Public/js/bootstrap.min.js
	slick = EXT:site_config/Resources/Public/js/slick.min.js
	matcheight = EXT:site_config/Resources/Public/js/jquery.matchHeight-min.js
	custom = EXT:site_config/Resources/Public/js/custom.js
}
page.includeJS.file1 = EXT:site_config/Resources/Public/js/jquery-1.12.4.min.js
