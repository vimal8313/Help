lib.footerText = RECORDS
lib.footerText.tables = tt_content
lib.footerText.source = 34

lib.footerImage = RECORDS
lib.footerImage.tables = tt_content
lib.footerImage.source = 35

