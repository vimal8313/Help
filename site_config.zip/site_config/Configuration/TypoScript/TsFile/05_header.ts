lib.logo = TEXT
lib.logo {
    value =  <div class="logo"><a href="{$baseURL}"><img src="typo3conf/ext/site_config/Resources/Public/images/innstolz-frischdienst-logo.png" alt=""></a></div>
}

lib.headerLeft = TEXT
lib.headerLeft {
    value = <div class="logo-one"><a href="{$baseURL}"><img src="typo3conf/ext/site_config/Resources/Public/images/innstolz-logo.svg" alt=""></a></div><div class="logo-two"><img src="typo3conf/ext/site_config/Resources/Public/images/frische-logo.png" alt=""></div><div class="image-one"><img src="typo3conf/ext/site_config/Resources/Public/images/maennchen.png" alt=""></div>
}

lib.mainNavi = HMENU
lib.mainNavi {
	#special = directory
	#special.value = 10
entryLevel = 0
	1 = TMENU
	1 {
		wrap = <ul class="nav navbar-nav">|</ul>
		NO {
		    #stdWrap.htmlSpecialChars = 1
		    wrapItemAndSub = <li>|</li>
		}
		
		expAll = 1
		IFSUB = 1
		IFSUB {
		   wrapItemAndSub = <li class="dropdown">|</li>
 		   ATagTitle.field = 1
		}
		ACT = 1
		ACT.wrapItemAndSub = <li class="dropdown active">|</li>
	}  
  	2 = TMENU
	2 {
		wrap = <div class="caret"><span></span></div><div class="dropdown-menu"><ul>|</ul></div>
		NO {
		    stdWrap.htmlSpecialChars = 1
		    wrapItemAndSub = <li>|</li>
		}
		CUR < .NO
		CUR = 1
		CUR {
			wrapItemAndSub = <li class="state-active">|</li>
		}
		#ACT = 1
		#ACT.wrapItemAndSub = <li class="state-active">|</li>
		expAll = 1
		IFSUB = 1
		IFSUB {
		   wrapItemAndSub = <li>|</li>
 		   ATagTitle.field = 1
		}
		
	}  
	3 = TMENU
	3 {
		wrap = <ul>|</ul>
		NO {
		    stdWrap.htmlSpecialChars = 1
		    wrapItemAndSub = <li>|</li>
		}
		#CUR < .NO
		#CUR = 1
		#CUR {
		#	wrapItemAndSub = <li class="state-active">|</li>
		#}
		ACT = 1
		ACT.wrapItemAndSub = <li class="sec-state-active">|</li>
	}  
}


lib.topNavi = HMENU
lib.topNavi {
 special = directory
  special.value = 12
  entryLevel = 0
  1 = TMENU
  1 {
    wrap = <ul>|</ul>
    NO {
      stdWrap.htmlSpecialChars = 1
      wrapItemAndSub = <li>|</li>
    }
    CUR < .NO
    CUR = 1
    CUR {
        wrapItemAndSub = <li>|</li>
    }

  }
}
