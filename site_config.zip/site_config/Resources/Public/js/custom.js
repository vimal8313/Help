(function ($) {
	$(window).on("load", function (e) {
		bannerSlider();
	});
	$(document).ready(function (e) {
		/*hoverMenu();*/
		$(".fm-main").matchHeight();
		contentHeight();
	});

	$(window).resize(function (e) {
		contentHeight();
	});

	function bannerSlider() {
		var $bannerSlider = $('.banner-slider').slick({
			autoplay: true,
			autoplaySpeed: 6000,
			dots: false,
			infinite: true,
			cssEase: 'linear'
		});
	}

	/*function hoverMenu(){
		$(".navbar-nav > li.dropdown").hover(function() {
			$(this).addClass('hover-active');
		}, function() {
			$(this).removeClass('hover-active');
		});
	}*/

	//Footer in bottom
	function contentHeight() {
		var header = $('header').outerHeight();
		var footer = $('footer').outerHeight();
		var winheight = $(window).height();
		var mainContent = winheight - (header + footer);
		$('#content .main-section').css('min-height', mainContent + 'px');
	}

})(jQuery);

$(document).on('ready', function () {
	$('.img-slider').slick({
		//vertical: true,
		/*infinite: true,*/
		/*slidesToShow: 1,
		slidesToScroll: 1,*/
		autoplay: true,
		autoplaySpeed: 3000,
		slidesToShow: 1,
		fade: true,
		cssEase: 'linear'
		/*responsive: [
		    {
		      breakpoint: 1024,
		      settings: {
		        vertical: false,
		      }
		    },
		    {
		      breakpoint: 600,
		      settings: {
		        vertical: false,
		      }
		    },
		    {
		      breakpoint: 480,
		      settings: {
		        vertical: false,
		      }
		    }
		    // You can unslick at a given breakpoint now by adding:
		    // settings: "unslick"
		    // instead of a settings object
		  ]*/
	});

	$(".nav .dropdown .caret").click(function () {
		if ($(this).next(".dropdown-menu").is(":visible")) {
			$(this).next(".dropdown-menu").slideUp();
			$(this).parent("li").removeClass("open");
		} else {
			$(".nav .dropdown .dropdown-menu").slideUp();
			$(".nav .dropdown").removeClass("open");
			$(this).next(".dropdown-menu").slideDown();
			$(this).parent("li").addClass("open");

		}
	});

});