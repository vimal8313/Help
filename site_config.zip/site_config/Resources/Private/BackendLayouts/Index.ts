backend_layout {
	colCount = 8
	rowCount = 3
	rows {
		1{
			columns {
				1 {
					name = Left
					colspan = 3
					colPos = 0
				}
				2 {
					name = Right
					colPos = 1
					
				}
				

			}
		}
		2{
			columns {
				1 {
					name = Content
					
					colPos = 402
				}

				2 {
					name = Content
					colPos = 403
				}
				3 {
					name = Content
					
					colPos = 404
				}

				4 {
					name = Content
					colPos = 405
				}
				

			}
		}
		3 {
	    columns {
		      1 {
		        name = Content
		        colPos = 401
		        colspan = 4
		       
		     }
	     }

      }
     
	}
}


