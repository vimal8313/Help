backend_layout {
  colCount = 2
  rowCount = 1
  rows {
  1 {
    columns {
      1 {
        name = Content
        colspan = 4
        colPos = 0
      }
     
    }
  }
 
}