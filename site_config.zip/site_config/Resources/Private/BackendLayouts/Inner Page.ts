backend_layout {
	colCount = 3
	rowCount = 2
	rows {
		1{
			columns {
				1 {
					name = Left
					colspan = 3
					colPos = 0
				}
				2 {
					name = Right
					colPos = 1
					
				}
				

			}
		}
		
		2 {
	    columns {
		      1 {
		        name = Content
		        colPos = 401
		        colspan = 4
		       
		     }
	     }

      }
     
	}
}


