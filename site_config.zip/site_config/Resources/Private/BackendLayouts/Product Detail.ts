backend_layout {
  colCount = 4
  rowCount = 3
  rows {
  1 {
    columns {
     
			1 {
				name = Center content
				colspan = 4
				colPos = 0
			}
			
    }
  }
  2 {
    columns {
      1 {
        name = Normal content
        colspan = 4
        colPos = 1
      }
     
    }
  }
 
}